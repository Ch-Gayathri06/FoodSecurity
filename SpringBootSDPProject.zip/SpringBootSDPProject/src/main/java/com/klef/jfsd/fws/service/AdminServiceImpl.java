package com.klef.jfsd.fws.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.fws.model.Donor;
import com.klef.jfsd.fws.model.FoodDonation;
import com.klef.jfsd.fws.repository.AdminRepository;
import com.klef.jfsd.fws.repository.DonorRepository;
import com.klef.jfsd.fws.repository.FoodDonationRepository;

@Service
public class AdminServiceImpl implements AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private DonorRepository donorRepository;

    @Autowired
    private FoodDonationRepository foodDonationRepository;

    @Override
    public String checkAdminLogin(String email, String password) {
        return adminRepository.checkadminlogin(email, password) != null
            ? "Admin Login Successful"
            : "Invalid Admin Credentials";
    }

    @Override
    public List<Donor> getAllDonors() {
        return donorRepository.findAll();
    }

    @Override
    public String deleteDonor(int donorId) {
        if (donorRepository.existsById(donorId)) {
            donorRepository.deleteById(donorId);
            return "Donor Deleted Successfully!";
        }
        return "Donor Not Found!";
    }

    @Override
    public String updateDonor(Donor donor) {
        Donor existingDonor = donorRepository.findById(donor.getId())
            .orElseThrow(() -> new RuntimeException("Donor not found"));

        // Update donor details
        existingDonor.setName(donor.getName());
        existingDonor.setEmail(donor.getEmail());
        existingDonor.setPassword(donor.getPassword());
        // Update other fields as necessary

        donorRepository.save(existingDonor);
        return "Donor Updated Successfully!";
    }

    @Override
    public List<FoodDonation> getAllFoodDonations() {
        return foodDonationRepository.findAll();
    }

    @Override
    public FoodDonation getFoodDonationById(int donationId) {
        return foodDonationRepository.findById(donationId)
            .orElseThrow(() -> new RuntimeException("Donation not found"));
    }

    @Override
    public String approveFoodDonation(int donationId) {
        FoodDonation donation = foodDonationRepository.findById(donationId)
            .orElseThrow(() -> new RuntimeException("Donation not found"));

        donation.setStatus("Approved");
        foodDonationRepository.save(donation);
        return "Food Donation Approved Successfully!";
    }

    @Override
    public String rejectFoodDonation(int donationId) {
        FoodDonation donation = foodDonationRepository.findById(donationId)
            .orElseThrow(() -> new RuntimeException("Donation not found"));

        donation.setStatus("Rejected");
        foodDonationRepository.save(donation);
        return "Food Donation Rejected Successfully!";
    }

    @Override
    public int getTotalDonors() {
        return (int) donorRepository.count();
    }

    @Override
    public int getTotalFoodDonations() {
        return (int) foodDonationRepository.count();
    }

    @Override
    public double getTotalFoodQuantity() {
        return foodDonationRepository.findAll()
            .stream()
            .mapToDouble(FoodDonation::getQuantity)
            .sum();
    }

    

    @Override
    public String sendNotificationToDonor(int donorId, String message) {
        Donor donor = donorRepository.findById(donorId)
            .orElseThrow(() -> new RuntimeException("Donor not found"));

        // Logic to send notification, e.g., via email or SMS
        System.out.println("Notification sent to donor: " + donor.getEmail() + " | Message: " + message);

        return "Notification Sent Successfully!";
    }

	@Override
	public List<FoodDonation> getPendingDonations() {
		// TODO Auto-generated method stub
		return null;
	}
}
