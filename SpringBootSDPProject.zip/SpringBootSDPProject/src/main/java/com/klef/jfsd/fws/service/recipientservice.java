package com.klef.jfsd.fws.service;

import com.klef.jfsd.fws.model.Recipient;

public interface recipientservice {
	public String addrecipient(Recipient r);
	public Recipient checkrecipientlogin(String email,String pwd);
}
