package com.klef.jfsd.fws.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.klef.jfsd.fws.model.Recipient;


@Repository
public interface recipientrepository extends JpaRepository<Recipient, Long>{
 
	@Query("select r from Recipient r where r.email=?1 and r.password=?2")
	public Recipient checkrecipientlogin(String email,String pwd);

}
