package com.klef.jfsd.fws.service;

import java.util.List;

import com.klef.jfsd.fws.model.Donor;
import com.klef.jfsd.fws.model.FoodDonation;

public interface AdminService {

    // Admin Login
    String checkAdminLogin(String email, String password);

    // Donor Management
    List<Donor> getAllDonors();
    String deleteDonor(int donorId);
    String updateDonor(Donor donor);

    // Food Donation Management
    List<FoodDonation> getAllFoodDonations();
    FoodDonation getFoodDonationById(int donationId);
    String approveFoodDonation(int donationId);
    String rejectFoodDonation(int donationId);

    // Reports and Statistics
    int getTotalDonors();
    int getTotalFoodDonations();
    double getTotalFoodQuantity();

    // Additional Features
    List<FoodDonation> getPendingDonations();
    String sendNotificationToDonor(int donorId, String message);
}
