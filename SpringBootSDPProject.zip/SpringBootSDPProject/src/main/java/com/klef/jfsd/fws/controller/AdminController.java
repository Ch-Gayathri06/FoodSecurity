package com.klef.jfsd.fws.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.klef.jfsd.fws.model.Donor;
import com.klef.jfsd.fws.model.FoodDonation;
import com.klef.jfsd.fws.service.AdminService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;

    // Admin login page
    @GetMapping("/adminlogin")
    public ModelAndView adminLogin() {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("adminlogin");
        return mv;
    }

    // Admin login process
    @PostMapping("/loginAdmin")
    public ModelAndView loginAdmin(HttpServletRequest request) {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String message = adminService.checkAdminLogin(email, password);

        ModelAndView mv = new ModelAndView();
        if (message.equals("Admin Login Successful")) {
            HttpSession session = request.getSession();
            session.setAttribute("admin", email); // Set admin session
            mv.setViewName("adminhome");
        } else {
            mv.setViewName("adminlogin");
            mv.addObject("message", "Invalid Admin Credentials");
        }
        return mv;
    }

    // Admin logout
    @GetMapping("/adminlogout")
    public ModelAndView adminLogout(HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.invalidate(); // Invalidate the session
        ModelAndView mv = new ModelAndView();
        mv.setViewName("adminlogin");
        mv.addObject("message", "Successfully logged out");
        return mv;
    }

    // View all donors
    @GetMapping("/viewDonors")
    public ModelAndView viewDonors(HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (session.getAttribute("admin") == null) {
            ModelAndView mv = new ModelAndView("adminlogin");
            mv.addObject("message", "Session expired. Please log in again.");
            return mv;
        }

        List<Donor> donors = adminService.getAllDonors();
        ModelAndView mv = new ModelAndView("viewdonors");
        mv.addObject("donors", donors);
        return mv;
    }

    // Delete donor
    @PostMapping("/deleteDonor")
    public ModelAndView deleteDonor(HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (session.getAttribute("admin") == null) {
            ModelAndView mv = new ModelAndView("adminlogin");
            mv.addObject("message", "Session expired. Please log in again.");
            return mv;
        }

        int donorId = Integer.parseInt(request.getParameter("donorId"));
        String msg = adminService.deleteDonor(donorId);

        ModelAndView mv = new ModelAndView("redirect:/viewDonors");
        mv.addObject("message", msg);
        return mv;
    }

    // View all food donations
    @GetMapping("/viewDonations")
    public ModelAndView viewDonations(HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (session.getAttribute("admin") == null) {
            ModelAndView mv = new ModelAndView("adminlogin");
            mv.addObject("message", "Session expired. Please log in again.");
            return mv;
        }

        List<FoodDonation> donations = adminService.getAllFoodDonations();
        ModelAndView mv = new ModelAndView("viewdonations");
        mv.addObject("donations", donations);
        return mv;
    }

    // Approve food donation
    @PostMapping("/approveDonation")
    public ModelAndView approveDonation(HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (session.getAttribute("admin") == null) {
            ModelAndView mv = new ModelAndView("adminlogin");
            mv.addObject("message", "Session expired. Please log in again.");
            return mv;
        }

        int donationId = Integer.parseInt(request.getParameter("donationId"));
        String msg = adminService.approveFoodDonation(donationId);

        ModelAndView mv = new ModelAndView("redirect:/viewDonations");
        mv.addObject("message", msg);
        return mv;
    }

    // Reject food donation
    @PostMapping("/rejectDonation")
    public ModelAndView rejectDonation(HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (session.getAttribute("admin") == null) {
            ModelAndView mv = new ModelAndView("adminlogin");
            mv.addObject("message", "Session expired. Please log in again.");
            return mv;
        }

        int donationId = Integer.parseInt(request.getParameter("donationId"));
        String msg = adminService.rejectFoodDonation(donationId);

        ModelAndView mv = new ModelAndView("redirect:/viewDonations");
        mv.addObject("message", msg);
        return mv;
    }

    // View pending donations
    @GetMapping("/viewPendingDonations")
    public ModelAndView viewPendingDonations(HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (session.getAttribute("admin") == null) {
            ModelAndView mv = new ModelAndView("adminlogin");
            mv.addObject("message", "Session expired. Please log in again.");
            return mv;
        }

        List<FoodDonation> pendingDonations = adminService.getPendingDonations();
        ModelAndView mv = new ModelAndView("viewpendingdonations");
        mv.addObject("pendingDonations", pendingDonations);
        return mv;
    }

    @GetMapping("adminhome")
    public ModelAndView adminhome()
       {
         ModelAndView mv = new ModelAndView();
         mv.setViewName("adminhome"); 
         
         return mv;
       }
}
