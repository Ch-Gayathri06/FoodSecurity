package com.klef.jfsd.fws.controller;

import com.klef.jfsd.fws.model.Recipient;
import com.klef.jfsd.fws.model.FoodDonation;

import com.klef.jfsd.fws.service.recipientservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;


import jakarta.servlet.http.HttpServletRequest;

@Controller
public class RecipientController {
	@Autowired
	private recipientservice rs;
	 @PostMapping("addrec")
	 public ModelAndView addrecipient(HttpServletRequest request)
	 {
		 ModelAndView mv= new ModelAndView();
		 String name=request.getParameter("name");
		 String gender=request.getParameter("gender");
		 String phone=request.getParameter("phone");
		 String email=request.getParameter("email");
		 String address=request.getParameter("address");
		 Double qneed=Double.parseDouble(request.getParameter("qneed"));
		 String fneed=request.getParameter("fneed");
		 String urgency=request.getParameter("urgency");
		 String ps=request.getParameter("password");
		 Recipient r= new Recipient();
		 r.setDeliveryAddress(address);
		 r.setEmail(email);
		 r.setFoodQuantity(qneed);
		 r.setFoodType(fneed);
		 r.setFullName(name);
		 r.setGender(gender);
		 r.setPhoneNumber(phone);
		 r.setUrgencyOfRequest(urgency);
		 r.setPassword(ps);
		 rs.addrecipient(r);
		 mv.setViewName("Recipientform");
		 return mv;
	 }

	  @PostMapping("checkrecilogin")
	  public ModelAndView checkrecipientlogin(HttpServletRequest request)
	  {
		   ModelAndView mv= new ModelAndView();
		   String email=request.getParameter("email");
		   String pd=request.getParameter("password");
		   
	 Recipient r =rs.checkrecipientlogin(email, pd);
		   if(r!=null)
		   {
			   mv.setViewName("recipientloginsuccess");
		   }
		   else
		   {
			   mv.setViewName("Recipientlogin");
		   }
		   return mv;
		   
	  }
	  
}
