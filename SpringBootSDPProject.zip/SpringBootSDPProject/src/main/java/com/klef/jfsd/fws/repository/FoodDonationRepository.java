package com.klef.jfsd.fws.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.klef.jfsd.fws.model.Donor;
import com.klef.jfsd.fws.model.FoodDonation;

public interface FoodDonationRepository  extends JpaRepository<FoodDonation, Integer> {

}
