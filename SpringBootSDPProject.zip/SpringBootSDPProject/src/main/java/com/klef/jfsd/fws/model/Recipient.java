package com.klef.jfsd.fws.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "recipient")
public class Recipient {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "full_name", nullable = false)
    private String fullName;

    @Column(name = "gender", nullable = false)
    private String gender;

    @Column(name = "phone_number", nullable = false, unique = true)
    private String phoneNumber;

    @Column(name = "email_address", nullable = false, unique = true)
    private String email;

    @Column(name = "delivery_address", nullable = false)
    private String deliveryAddress;

    @Column(name = "food_type", nullable = false)
    private String foodType;

    @Column(name = "food_quantity", nullable = false)
    private Double foodQuantity;

    @Column(name = "urgency_of_request", nullable = false)
    private String urgencyOfRequest;
    
    private String password;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	

	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(String deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public Double getFoodQuantity() {
		return foodQuantity;
	}

	public void setFoodQuantity(Double foodQuantity) {
		this.foodQuantity = foodQuantity;
	}

	public String getUrgencyOfRequest() {
		return urgencyOfRequest;
	}

	public void setUrgencyOfRequest(String urgencyOfRequest) {
		this.urgencyOfRequest = urgencyOfRequest;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
    
}