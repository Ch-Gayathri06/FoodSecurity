package com.klef.jfsd.fws.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klef.jfsd.fws.model.Recipient;
import com.klef.jfsd.fws.repository.recipientrepository;


@Service
public class recipientserviceimpl implements recipientservice {

	@Autowired
	private recipientrepository rr;
	
	public String addrecipient(Recipient r) {
		// TODO Auto-generated method stub
		rr.save(r);
		return "Added successfully";
	}

	@Override
	public Recipient checkrecipientlogin(String email, String pwd) {
		// TODO Auto-generated method stub
		return rr.checkrecipientlogin(email, pwd);
	}
}


