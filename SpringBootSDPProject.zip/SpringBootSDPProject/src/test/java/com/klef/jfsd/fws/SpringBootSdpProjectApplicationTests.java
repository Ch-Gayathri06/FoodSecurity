package com.klef.jfsd.fws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSdpProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
